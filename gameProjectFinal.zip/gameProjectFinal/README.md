# Classic Arcade Game Clone

---

## Introduction

Arcade Game Project is for Intermediate Javascript section in Udacity's Front-End Web Developer Nanodegree.

Main objectives of this project:

* Given some game assets and a game loop engine, create the classic arcade game Frogger
* Use object-oriented features of JavaScript to write well-designed classes
* Work with HTML5 canvas to draw texts and load images

## Files

The followings are the files that I have worked on:
In js folder: 
* **js/app.js:** The main JavaScript file with JavaScript classes for Enemy, Player. I have made many functions in this file. 

* **js/engine.js:** This file provides the game loop functionality. This file works by drawing the entire game screen over and over. 

The followings are the folders that are already provided by Udacity to complete this project:

* **index.html:** This HTML5 helps to load the JavaScript and CSS files

* **js/resources.js:** This file in included in js folder, which helps to load  and images. 

* **css/style.css:** This file provides some CSS styles. 

* **images:** This folder contains png images which are user to when displaying the game. 

## Running The Project

1. Download the zip file. 

2. Open *index.html* in a web browser (I recommend Google Chrome)

## Steps to play

* Th front page of the game will be displayed and you can choose between the five players by clicking number 1 to 5 in the keyboard. 

* To move your player from the grass to the water, press the arrow keys. Be careful, don't hit any of the bugs.

* You will go back to the grass if you hit any bug. 

* If you reach the water without hitting the bugs. Then you earn 10 points and jump one level. 

* When you are in level 3 and collect 30 points then congrats you win.  

