"use strict;"
var go = false;
var playerimg = 'images/char-cat-girl.png';
var score = 0;
var level = 0;
var live = 3;

// Enemies our player must avoid
var Enemy = function(y, speed) {
    // Variables applied to each of our instances go here,
    // we've provided one for you to get started

    // The image/sprite for our enemies, this uses
    // a helper we've provided to easily load images
    this.sprite = 'images/enemy-bug.png';
    this.x = -50;
    this.y = y;
    this.speed = speed;
};

// This function Update the enemy's position.
Enemy.prototype.update = function(dt) {
    // You should multiply any movement by the dt parameter
    // which will ensure the game runs at the same speed for
    // all computers.
    if (this.x < 505) { // 
        this.x = this.x + (this.speed * dt);
    } else {
        this.x = -100;
    }
};

// Draw the enemy on the screen, required method for game
Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

// This is player class
var Player = function() {
  
    this.sprite = playerimg;;
    this.x = 202;
    this.y = 400;
    this.speed = 10;
}


//This function reset the player to its original loaction.
Player.prototype.reset = function() {
    this.x = 202;
    this.y = 400;
};

//this function update the score and level of the player 
Player.prototype.update = function() {
    this.checkCollisions();
    if (this.y <= 0) {
        this.reset();
        level = level + 1;
        score = score + 10;
        console.log('You got 10 points and one level!!');
    }

    if (score >= 30 && level >= 3) {
        console.log('Congrat you win!');
        //this.renderWinPage();

    }


};

Player.prototype.renderScore = function(){
    ctx.fillStyle = "#800000";
    ctx.fillRect(0, 550, 505,50);
    ctx.strokeStyle = "#669900";   
    ctx.font = "24px  Times";
    ctx.strokeText("Level: ", 20, 580);
    ctx.strokeText("Score: ", 170, 580);
    ctx.strokeText("Live: ", 320, 580);
    ctx.font = "24px  Times";
    ctx.strokeText(level, 90, 580);
    ctx.strokeText(score , 240, 580);
    ctx.strokeText(live, 380, 580);
    ctx.save();
};

Player.prototype.render = function() {
    this.renderScore();
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
}

//this function handel all of the arrow keys input as well as chooseing player (1-5)
Player.prototype.handleInput = function(key) {
    if (key === 'left' && this.x > 30) {
        this.x -= 100;
    } else if (key === 'right' && this.x < 395) {
        this.x += 100;
    } else if (key === 'up' && this.y > 0) {
        this.y -= 85;
    } else if (key === 'down' && this.y < 400) {
        this.y += 85;
    }
    // switch
    switch (key) {
        case '1':
            this.sprite = 'images/char-boy.png';
            go = true;
            break;
        case '2':
            this.sprite = 'images/char-horn-girl.png';
            go = true;
            break;
        case '3':
            this.sprite = 'images/char-cat-girl.png';
            go = true;
            break;
        case '4':
            this.sprite = 'images/char-pink-girl.png';
            go = true;
            break;
        case '5':
            this.sprite = 'images/char-princess-girl.png';
            go = true;
            break;
        default:
            go = true;
            break;

    }
};

Player.prototype.lives = function() {
    live = live - 1;
    if (live < 1) {
        console.log('Hard luck!');
        //this.renderGameoverPage();
        
    }
};

var rect1 = {
    width: 50,
    height: 50
}

//this function check if there is any collosion between the player and the bugs    
Player.prototype.checkCollisions = function() {
    for (var hit = 0; hit < allEnemies.length; hit++) {
        if (this.x < allEnemies[hit].x + rect1.width && this.x + rect1.width > allEnemies[hit].x && this.y < allEnemies[hit].y + rect1.height && this.y + rect1.height > allEnemies[hit].y) {
            console.log('Collisions');
            this.reset();
            this.lives();//decrease number of lives.
            
        }
    }

}

// Place the player object in a variable called player
var player = new Player();
var enemy1 = new Enemy(60, 260);
var enemy2 = new Enemy(140, 300);
var enemy3 = new Enemy(220, 180);
var enemy4 = new Enemy(220, 400);
// Place all enemy objects in an array called allEnemies
var allEnemies = [enemy1, enemy2, enemy3, enemy4];

document.addEventListener('keyup', function(e) {

    console.log(e.keyCode);
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down',
        13: 'return',
        49: '1',
        50: '2',
        51: '3',
        52: '4',
        53: '5',
        54: '6',
        55: '7',
        56: '8',
        57: '9'
    };

    player.handleInput(allowedKeys[e.keyCode]);
});